package IA;

public class AplicacaoExcepition extends Exception  {

	public AplicacaoExcepition(String message) {
        super(message);
    }

    public AplicacaoExcepition(Throwable t) {
        super(t);
    }

}
