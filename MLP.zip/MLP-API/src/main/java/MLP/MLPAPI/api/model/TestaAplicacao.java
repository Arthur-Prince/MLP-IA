package MLP.MLPAPI.api.model;


public class TestaAplicacao {
    
    private String dados;
    
    public TestaAplicacao(String dados) {
	this.dados = dados;
    }

    
}
